#include<iostream>
#include<fstream>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
#include<windows.h>
#include <ctime>
using namespace std;
int main();
int login()
{
       
        int count=0;
        string user,pass,u,p;
        system("cls");
        cout<<"                                                                                                                                                                       "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             *******************************************************************************************              \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                  ~~~ LOGIN ~~~~                                                      \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             ****************************   PLEASE ENTER YOUR CREDENTIALS  *****************************               \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                USERNAME : ";        cin>>user;                   
        cout<<"\n                                                                                                PASSWORD : ";        cin>>pass;                                             
        cout<<"                                                                                                                                                                      \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        
	       
        

        ifstream input("database.txt");
        while(input>>u>>p)
        {
                if(u==user && p==pass)
                {
                        count=1;
                       
                }
        }
        input.close();
        if(count==1)
        {
                 cout<<"\n                                                                                                HELLO  "<<user;
                cout<<"\n                                                                                                LOGIN SUCESS ";
                cout<<"\n                                                                                                We're glad that you're here...";
                cout<<"\n                                                                                                Thanks for logging in!!\n";
                Sleep(1500);
            
        }
        else
        {       char o;
                cout<<"\n                                                                                                LOGIN ERROR!!";
				cout<<"\n                                                                                                Please check your USERNAME and PASSWORD  (*_*) \n";
				Sleep(1000);
				cout<<"\n                                                                                                Do you want to re-enter your USERNAME and PASSWORD ? Y/N";
				cout<<"\n                                                                                                "; cin>>o;
				if(o=='y'||o=='Y')
				{    return login();
			    }
			    else
			    {
			    	exit(0);
				}
        }
}
int registr()
{
        string reguser,regpass,ru,djob,fsc,bfr,nic,rp;
        int sec;
        system("cls");
        cout<<"                                                                                                                                                                       "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             *******************************************************************************************              \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                   ~~~ SIGN UP ~~~~                                                \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             **********************************   REGISTER NEW USER  ***********************************               \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                         Enter the username : ";        cin>>reguser;                   
        cout<<"                                                                                         Enter the password : ";        cin>>regpass;                 
		cout<<"\n                                                                                         CHOOSE SECURITY QUESTION FROM BELOW:                                         \n";       
		cout<<"                                                                                         1.What is your dream job ?                                                   \n";
		cout<<"                                                                                         2.What was your first school name ?                                          \n";
        cout<<"                                                                                         3.What is the name of your best friend ?                                     \n";
	    cout<<"                                                                                         4.What is your nickname ?                                                   \n\n";     
	    label:
		cout<<"                                                                                         Choose your option : "; cin>>sec; 
		switch(sec)
        {
                case 1:
                     cout<<"                                                                                         Your dream job is : ";cin>>djob;
                     break;
                case 2:
                     cout<<"                                                                                         Your first school name is  : ";cin>>fsc;
                     break;
                case 3:
                     cout<<"                                                                                         Your best friend name is  : ";cin>>bfr;
                     break;
                case 4:
                	 cout<<"                                                                                         Your nickname is  : ";cin>>nic;
                     
          default://for wrong input
            cout << "\n\n                                                                                         Wrong input entered :< TRY AGAIN .\n\n" << endl;
            goto label ;
        
                
        }
        
        
                                                                                                                              
        

        ofstream reg("database.txt");
        reg<<reguser<<' '<<regpass<<' '<<sec<<' '<<djob<<' '<<fsc<<' '<<bfr<<' '<<nic<<endl;
        cout<<"\n\n                                                                                         Registration Sucessful  \n";
        cout<<"\n                                                                                         LOGIN WITH YOUR CREDENTIALS TO ENJOY OUR SERVICE :} ";
        Sleep(1000);
   
}

void forgot()
{ int ch;
        system("cls");
        cout<<"                                                                                                                                                                       "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             *******************************************************************************************              \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                ~~~ Forgotten ?  ~~~~                                           \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                             **********************************  We're here for help  ***********************************               \n";
        cout<<"                                                                                                                                                                      "<<endl;
        cout<<"                                                                                         1.Search your id by username                                                 "<<endl;
        cout<<"                                                                                         2.Enter your security answer                                                 "<<endl;
	    cout<<"                                                                                         3.Back to Menu                                                                  "<<endl;
        cout<<"                                                                                         Enter your choice :                                                          "<<endl;
        cout<<"                                                                                         ";cin>>ch;
        switch(ch)
        {
                case 1:
                {
                        int count=0;
                        string searchuser,su,sp;
                        cout<<"\n                                                                                         Enter your remembered username :";cin>>searchuser;

                        ifstream searchu("database.txt");
                        while(searchu>>su>>sp)
                        {
                                if(su==searchuser)
                                {
                                        count=1;
                                }
                        }
                        searchu.close();
                        if(count==1)
                        {
                                cout<<"\n\n                                                                                         Hurray, account found :> \n";
                                cout<<"\n                                                                                         Your password is :  "<<sp;
                                cin.get();
                                cin.get();
                                system("cls");
                                main();
                        }
                        else
                        {
                                cout<<"\n                                                                                         Sorry, Your userID is not found in our database :< \n";
                                cin.get();
                                cin.get();
                                main();
                        }
                        break;
                }
                case 2:
                {
                        int count=0;
                        string searchpass,sec,su2,sp2;
                        cout<<"\n                                                                                         The Security Questions were:                                               \n";
                        cout<<"                                                                                         1.What is your dream job ?                                                   \n";
	                	cout<<"                                                                                         2.What was your first school name ?                                          \n";
                        cout<<"                                                                                         3.What is the name of your best friend ?                                     \n";
	                    cout<<"                                                                                         4.What is your nickname ?                                                   \n\n"; 
						cout<<"                                                                                         You chose question no. :  " <<sec<<endl;   
                        cout<<"\n                                                                                         Enter the security answer :";cin>>searchpass;
                        

                        ifstream searchp("database.txt");
                        while(searchp>>su2>>sp2)
                        {
                                if(sp2==searchpass)
                                {
                                        count=1;
                                }
                        }
                        searchp.close();
                        if(count==1)
                        {
                                cout<<"\nYour password is found in the database \n";
                                cout<<"\nYour Id is : "<<su2;
                                
                                system("cls");
                                main();
                        }
                        else
                        {
                                cout<<"Sorry, We cannot found your password in our database \n";
                                cout<<"\nkindly contact your administrator for more information\n";
                                
                                main();
                        }

                        break;
                }

                case 3:
                {
                        cin.get();
                        main();
                }
                default:
                        cout<<"Sorry, You entered wrong choice. Kindly try again"<<endl;
                        forgot();
        }
}

int login_page()
       {   
	    int choice;
	    cout<<"\n\n\n\n                                           ============================================================================================================================"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 *******************************************************************************************              |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                    WELCOME TO LOGIN PAGE!!                                               |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ****************************************    MENU   ****************************************              | \n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                        1.LOGIN                                                           |\n";
        cout<<"                                           |                                                        2.REGISTER                                                        |\n";
        cout<<"                                           |                                                        3.FORGOT PASSWORD/USERNAME                                        |\n";
        cout<<"                                           |                                                        4.EXIT                                                            |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl; 
	    cout<<"                                           ============================================================================================================================"<<endl;
	    cout<<"                                                                                                 Enter your choice : ";  cin>>choice;     
        switch(choice)
        {
                case 1:
                        login();
                        break;
                case 2:
                        registr();
                        system("CLS");
                        return login_page();
                        break;
                case 3:
                        forgot();
                        break;
                case 4:
				system("CLS");
		    	cout<<"\n\n                                                                                                Thanks for visiting!!!";  
		    	return 0; 
                default://for wrong input
                cout << "                                                                                                 Wrong input entered\n                                                                                                 Try again.\n\n\n\n" << endl;
                return login_page();
                
        }
}


int glob=0; //global variable

class d_booking //class  for domestic booking
{
protected:
    int pnr;
    char f_d[10],toja[7],todh[10]; 
    int dd , mm , yy;
    int cat, f_class;
    char age_cat[50],fl_class[50];
    int choice,src,dest,k;
public:
void d_pnr()
    {
        glob++; 
        pnr=glob;
    }
    int dj_detail() // function declaration and definition for domestic journey
    {
    	time_t t = time(NULL);
      tm* tPtr = localtime(&t); 
	dd_re:
	cout << "                                                                                         Enter the Date of Journey :\n";
	cout << "                                                                                         Day [DD](in num) : ";cin >> dd;
	if (dd < 0 || dd > 31 ) {
		cout << "                                                                                         You Entered an invalid date . Please Try Again\n";
		goto dd_re;
	}
   mm_re:
	cout << "                                                                                         Month [MM] : ";cin >> mm;
	if (mm < 0 ||  mm > 12) {
		cout << "\n                                                                                        Months are in range (1 - 12) only, Please make a correct choice \n";
		goto mm_re;
	}
	if(mm<(tPtr->tm_mon)+1)
	{
		cout<<"\n                                                                                         INVALID INPUT!!   \n";
		goto mm_re;
	}
	if(dd<tPtr->tm_mday && mm<=(tPtr->tm_mon)+1)
	{
		cout<<"                                                                                         INVALID INPUT!! \n                                                                                         Please enter the date again\n";
		goto dd_re;
	}
	if(dd==tPtr->tm_mday && mm==(tPtr->tm_mon)+1)
	{
		cout<<"                                                                                         Bookings are closed!!!   \n"<<"                                                                                         SORRY FOR THE INCONVENIENCE\n";
		cout<<"                                                                                         Flights are available for the next days\n";
		goto dd_re;
	}
	if(mm-((tPtr->tm_mon)+1)>5)
	{
		cout<<"                                                                                         You are too early for bookings.\n";
		cout<<"                                                                                         TRY TO BOOK FOR THE DATE WHICH IS NOT SO FAR FROM THE PRESENT TIME\n";
		goto dd_re;
	}
	if (mm == 2 && dd > 28 ) {
		cout << "                                                                                         February , 2021 has only 28 Days . Please enter the date again\n";
		goto dd_re;
	}
	if(mm == 4  && dd > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto dd_re;
	}
	if(mm == 6 && dd > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto dd_re;
	}
	if(mm == 9 && dd > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto dd_re;
	}
	if(mm == 11 && dd > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto dd_re;
	}
	
yy_re:
	cout << "                                                                                         Year [YYYY] : ";
	cin >> yy;

	if (yy != 2022) {
		cout << "                                                                                         INVALID INPUT  \nYou can only book tickets for current year.\n";
		goto yy_re;
	}
    }
    int flight_class()
    {
    	cout<<"\n                                                                                         Date of Journey you enterned is(DD/MM/YYYY):"<<dd<<"/"<<mm<<"/"<<yy;
    	Sleep(500);
        cout<<"\n\n                                                                                         Available Flights!!       ";
		cout<<"\n                                                                                         1.Dehli(1)   to Mumbai(2)         7.Mumbai(2)    to Dehli(1)\n";
		cout<<"\n                                                                                         2.Dehli(1)   to Kolkata(3)        8.Kolkata(3)   to Delhi(1)\n";
		cout<<"\n                                                                                         3.Dehli(1)   to Bengaluru(4)      9.Bengaluru(4) to Delhi(1) \n";
		cout<<"\n                                                                                         4.Mumbai(2)  to Kolkata(3)        10.Kolkata(3)   to Mumbai(2) \n";
		cout<<"\n                                                                                         5.Mumbai(2)  to Bengaluru(4)      11.Bengaluru(4) to Mumbai(2)  \n";
		cout<<"\n                                                                                         6.Kolkata(3) to Bengaluru(4)      12.Bengaluru(4) to Kolkata(3)   \n";
		cout<<"\n\n                                                                                         Choose your source and destination by selecting below options :  ";
        cout <<"\n                                                                                         1. DELHI  2.MUMBAI  3.KOLKATA  4.BENGALURU" ;
        cout <<"\n                                                                                         Enter your Source : " ;cin >> src;
        cout <<"\n                                                                                         Enter your destination : " ; cin >> dest;
        if((src==1 && dest==2) || (src==2 && dest==1))
        {
            cout <<"\n\n                                                                                         FLIGHTS FOUND :) \n" << endl; 
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl; 
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
           cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl; 
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl; 
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
           cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
           cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.AIR INDIA\t08:00 AM\t\t11:05 AM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t17:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Go Air\t19:00 PM\t\t22:05 PM\t\tRefundable\n";
        }
        else if(src==dest)
        {
            cout << "\n\n                                                                                         Source and destination can't be same!! \n                                                                                         Try again\n" << endl;
            return flight_class();
        }
        else
        {
            cout <<"\n\n                                                                                         Wrong input entered !! \n                                                                                         Try again\n" << endl;
            return flight_class();
        }
    	cout<<"\n\n                                                                                         Enter your preferred flight class : \n";
        cout<<"                                                                                         1.Business Class \n                                                                                         2.Economic Class";
		cout<<"\n                                                                                         Choose your option : "; cin>>f_class;
        	if(f_class==1)
        	{
		      strcpy(fl_class,"Business Class");
		      age_buscategory();
		    }
			else if(f_class==2)
			{
		      strcpy(fl_class,"Economic Class");
		      age_category();
	        }
			else
			{
				cout<<"\n                                                                                         ERROR!!!"<<endl;
				return flight_class();
			}
	} 	
    int age_category()// function for age category and price for business class
    {
    	cout<<"\n                                                                                         Passenger Age Category : \n";
        cout<<"                                                                                         1.Infant(1-2)\n ";
		cout<<"                                                                                         2.Children(3-12)\n";
		cout<<"                                                                                         3.Adult(>12)\n";
        cout<<"                                                                                         Select your Category : ";cin>>cat;
       	if(cat==1)
       	{
		strcpy(age_cat,"INFANT");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant  \n\n";
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.800\n";
            cout << "                                                                                         2.INDIGO\t\tRs.1300\n";
            cout << "                                                                                         3.Go Air\t\tRs.1800\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n";
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.700\n";
            cout << "                                                                                         2.INDIGO\t\tRs.550\n";
            cout << "                                                                                         3.Go Air\t\tRs.800\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.600\n";
            cout << "                                                                                         2.INDIGO\t\tRs.850\n";
            cout << "                                                                                         3.Go Air\t\tRs.2000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.750\n";
            cout << "                                                                                         2.INDIGO\t\tRs.400\n";
            cout << "                                                                                         3.Go Air\t\tRs.550\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.450\n";
            cout << "                                                                                         3.Go Air\t\tRs.600\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.750\n";
            cout << "                                                                                         2.INDIGO\t\tRs.680\n";
            cout << "                                                                                         3.Go Air\t\tRs.700\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
         }
    	}
		else if(cat==2)
		{
		strcpy(age_cat,"Children");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2750\n";
            cout << "                                                                                         3.Go Air\t\tRs.3000\n";
            cout<<"                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5500\n";
            cout << "                                                                                         3.Go Air\t\tRs.6000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2125\n";
            cout << "                                                                                         3.Go Air\t\tRs.3050\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
       		cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2700\n";
            cout << "                                                                                         2.INDIGO\t\tRs.1250\n";
            cout << "                                                                                         3.Go Air\t\tRs.1445\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2600\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2000\n";
            cout << "                                                                                         3.Go Air\t\tRs.3150\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2750\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2890\n";
            cout << "                                                                                         3.Go Air\t\tRs.3500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
         }
    	}
		else if(cat=3)
	    {
		    strcpy(age_cat,"Adult");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5500\n";
            cout << "                                                                                         3.Go Air\t\tRs.6000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5500\n";
            cout << "                                                                                         3.Go Air\t\tRs.6000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.4000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4250\n";
            cout << "                                                                                         3.Go Air\t\tRs.6100\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5400\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2500\n";
            cout << "                                                                                         3.Go Air\t\tRs.2890\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4500\n";
            cout << "                                                                                         3.Go Air\t\tRs.6000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.5800\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5508\n";
            cout << "                                                                                         3.Go Air\t\tRs.6050\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
		}
		else
		{
				cout<<"                                                                                         ERROR!!!"<<endl;
				return age_category();
		}
	}
	int age_buscategory()// function for category and price for Business class
    {
    	cout<<"\n                                                                                         Passenger Age Category:\n";
        cout<<"                                                                                         1.Infant(1-2)\n";
		cout<<"                                                                                         2.Children(3-12)\n";
		cout<<"                                                                                         3.Adult(>12)\n";
        cout<<"                                                                                         Select your Category : ";cin>>cat;
       	if(cat==1)
        	{
		strcpy(age_cat,"INFANT");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.1500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2000\n";
            cout << "                                                                                         3.Go Air\t\tRs.2500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
            cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.2000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2500\n";
            cout << "                                                                                         3.Go Air\t\tRs.3500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
            cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.900\n";
            cout << "                                                                                         2.INDIGO\t\tRs.1250\n";
            cout << "                                                                                         3.Go Air\t\tRs.2500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.1610\n";
            cout << "                                                                                         2.INDIGO\t\tRs.1250\n";
            cout << "                                                                                         3.Go Air\t\tRs.950\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.1000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.950\n";
            cout << "                                                                                         3.Go Air\t\tRs.1100\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant \n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.1000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2100\n";
            cout << "                                                                                         3.Go Air\t\tRs.1500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
	}
			else if(cat==2)
			{
		strcpy(age_cat,"Children");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.3750\n";
            cout << "                                                                                         3.Go Air\t\tRs.4000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
       		cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.3500\n";
            cout << "                                                                                         3.Go Air\t\tRs.4000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.3125\n";
            cout << "                                                                                         3.Go Air\t\tRs.4050\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3700\n";
            cout << "                                                                                         2.INDIGO\t\tRs.2250\n";
            cout << "                                                                                         3.Go Air\t\tRs.2445\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
            cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3600\n";
            cout << "                                                                                         2.INDIGO\t\tRs.3000\n";
            cout << "                                                                                         3.Go Air\t\tRs.4150\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
            cout<<"                                                                                         Your selected class is Business and selected Age Category is Children \n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.3750\n";
            cout << "                                                                                         2.INDIGO\t\tRs.3890\n";
            cout << "                                                                                         3.Go Air\t\tRs.4500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
	}
		    else if(cat=3)
		    {
		    strcpy(age_cat,"Adult");
		if((src==1 && dest==2) || (src==2 && dest==1))
        {
       		cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.8000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Go Air\t\tRs.8000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==3) || (src==3 && dest==1))
        {
       		cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
            cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.8000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Go Air\t\tRs.7500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==1 && dest==4) || (src==4 && dest==1))
        {
       		cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.6000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.6250\n";
            cout << "                                                                                         3.Go Air\t\tRs.8100\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==3) || (src==3 && dest==2))
        {
       		cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.7400\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4500\n";
            cout << "                                                                                         3.Go Air\t\tRs.4890\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==2 && dest==4) || (src==4 && dest==2))
        {
        	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.7000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.6500\n";
            cout << "                                                                                         3.Go Air\t\tRs.8000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((src==3 && dest==4) || (src==4 && dest==3))
         {
         	cout<<"\n                                                                                    $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult \n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.AIR INDIA\t\tRs.8800\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8508\n";
            cout << "                                                                                         3.Go Air\t\tRs.8050\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
		}
			else
			{
				cout<<"                                                                                         ERROR!!!"<<endl;
				return age_buscategory();
			}
	}
    int  select_flight() //function declaration and definition for selecting flight
    {   
        cout<<endl<<"                                                                                         Select your airline from below options : \n";
		cout<<"                                                                                         1.Air India \t 2.Indigo \t 3.Go Air"<<endl;
	    cout << "\n                                                                                         Enter your choice : " ;cin >> choice;
	    char todh[10];
        switch(choice) 
        {
          case 1:
                cout << "\n                                                                                         Flight selected : "<<endl;
                cout << "                                                                                         AIR INDIA"<<endl;
                strcpy(f_d,"AIR INDIA");
                cout << "                                                                                         Departure Time : 08:00 AM"<<endl;
                cout<<"                                                                                         Arrival Time: 11:05 AM"<<endl;
                strcpy(todh, "8:00 AM"); 
                strcpy(toja,"11:05 AM");
                break;
          case 2:
                cout << "\n                                                                                         Flight selected :"<<endl;
                cout << "                                                                                         INDIGO "<<endl;
                strcpy(f_d,"INDIGO   ");
                cout <<"                                                                                         Departure Time : 14:00 PM"<<endl;
                cout<<"                                                                                         Arrival Time: 17:05 PM"<<endl;
                strcpy(todh,"14:00 PM");
                strcpy(toja,"17:05 PM");
                break;
          case 3:
                cout << "\n                                                                                         Flight selected:" << endl;
                cout << "                                                                                         GO AIR " << endl;
                strcpy(f_d,"Go Air   ");
                cout << "                                                                                         Departure Time : 19:00 PM" << endl;
                cout<<"                                                                                         Arrival Time: 22:05 PM" << endl;
                strcpy(todh,"19:00 PM");
                strcpy(toja,"22:05 PM");
                break;
          default:
                cout << "                                                                                         Wrong input entered.\nTry again" << endl;
                return select_flight();
        }
    }
};
class i_booking //class  for international booking
{
protected:
    int pnri;
    char f_i[10],tojai[7],tojdi[22]; 
    int ddi , mmi , yyi;
    int cati, f_classi,busi,ecoi;
    char age_cati[100],fl_classi[100];
    int choicei,srci,desti;
    char pass[100];
public:
void i_pnr()
    {
        glob++; 
        pnri=glob;
    }
    int ij_detail() // function declaration and definition for domestic journey
    {   cout<<"\n                                                                                         Enter your Passport no. : ";cin>>pass;
    	time_t t = time(NULL);
      tm* tPtr = localtime(&t); 
	ddi_re:
	cout << "                                                                                         Enter the Date of Journey :\n";
	cout << "                                                                                         Day [DD](in num) : ";
	cin >> ddi;
	if (ddi < 0 || ddi > 31 ) {
		cout << "\n                                                                                         You Entered an invalid date . Please Try Again\n";
		goto ddi_re;
	}
   mmi_re:
	cout << "\n                                                                                           Month [MM] : ";
	cin >> mmi;
	if (mmi < 0 ||  mmi > 12) {
		cout << "\n                                                                                       Months are in range (1 - 12) only, Please make a correct choice \n";
		goto mmi_re;
	}
	if(mmi<(tPtr->tm_mon)+1)
	{
		cout<<"\n                                                                                         INVALID INPUT!!   \n";
		goto mmi_re;
	}
	if(ddi<tPtr->tm_mday && mmi<=(tPtr->tm_mon)+1)
	{
		cout<<"                                                                                         INVALID INPUT!! \n                                                                                         Please enter the date again\n";
		goto ddi_re;
	}
	if(ddi==tPtr->tm_mday && mmi==(tPtr->tm_mon)+1)
	{
		cout<<"                                                                                         Bookings are closed!!!   \n"<<"                                                                                         SORRY FOR THE INCONVENIENCE\n";
		cout<<"                                                                                         Flights are available for the next days\n";
		goto ddi_re;
	}
	if(mmi-((tPtr->tm_mon)+1)>5)
	{
		cout<<"                                                                                         You are too early for bookings.\n";
		cout<<"                                                                                         TRY TO BOOK FOR THE DATE WHICH IS NOT SO FAR FROM THE PRESENT TIME\n";
		goto ddi_re;
	}
	if (mmi == 2 && ddi > 28 ) {
		cout << "                                                                                         February , 2021 has only 28 Days . Please enter the date again\n";
		goto ddi_re;
	}
	if(mmi == 4  && ddi > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto ddi_re;
	}
	if(mmi == 6 && ddi > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto ddi_re;
	}
	if(mmi == 9 && ddi > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto ddi_re;
	}
	if(mmi == 11 && ddi > 30)
	{
		cout<<"                                                                                         INVALID INPUT!!!   \n";
		goto ddi_re;
	}
	
yyi_re:
	cout << "                                                                                         Year [YYYY] : ";
	cin >> yyi;

	if (yyi != 2021) {
		cout << "                                                                                         INVALID INPUT  \n                                                                                         You can only book tickets for current year.\n";
		goto yyi_re;
	}
    }
    int flight_classi()
    {
    	cout<<"\n                                                                                         Date of Journey you enterned is(DD/MM/YYYY) : "<<ddi<<"/"<<mmi<<"/"<<yyi;
        cout<<"\n                                                                                         Available Flights!!  ";
		cout<<"\n                                                                                         1.London(1) to France(3)        7.France(3)    to London(1)\n"; 
		cout<<"                                                                                         2.London(1) to Singapore(4)     8.Singapore(4) to London(1)\n"; 
		cout<<"                                                                                         3.London(1) to NewYork(5)       9.NewYork(5)   to London(1)\n"; 
		cout<<"                                                                                         4.India(2)  to France(3)       10.France(3)    to India(2)\n ";
		cout<<"                                                                                         5.India(2)  to Singapore(4)    11.Singapore(4) to India(2)\n"; 
		cout<<"                                                                                         6.India(2)  to NewYork(5)      12.NewYork(5)   to India(2)"<<endl;
		cout<<"\n                                                                                         Choose your source and destination by selecting below options.\n";
        cout<< "                                                                                         1.London 2.India 3.France 4.Singapore 5.NewYork " << endl << endl;
        cout << "\n                                                                                         Enter your Source : "; cin >> srci;
        cout << "\n                                                                                         Enter your destination : " ;cin >> desti;
        if((srci==1 && desti==3) || (srci==3 && desti==1))//condition
        {
        	cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((srci==1 && desti==4) || (srci==4 && desti==1))//condition
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((srci==1 && desti==5) || (srci==5 || desti==1))//condition
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((srci==2 && desti==3) || (srci==3 && desti==2))//condition
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";
        }

        else if((srci==2 && desti==4) || (srci==4 && desti==2))//condition
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";      
	    }

        else if(srci==2 && desti==5 || (srci==5 && desti==2))//condition
        {
            cout <<"\n\n                                                                                       FLIGHTS FOUND :) " << endl;
            cout << "                                                                                         Airline:\tDeparture:\t\tArrival:\t\tCategory:\n";
            cout << "                                                                                         1.Vistara\t10:00 AM\t\t14:05 PM\t\tRefundable\n";
            cout << "                                                                                         2.INDIGO\t14:00 PM\t\t18:05 PM\t\tRefundable\n";
            cout << "                                                                                         3.Emirates\t18:00 PM\t\t22:05 PM\t\tRefundable\n";

        }
        else if(srci==desti)//condition
        {
            cout << "                                                                                         Wrong input entered\n                                                                                         Try again\n\n\n"<< endl;
            return flight_classi();
        }
        else//condition
            {
            cout << "                                                                                         Sorry We dont fly here!!\n                                                                                         If you want you can check for other flights available\n\n\n";
            return flight_classi();
        }
    	cout<<"\n                                                                                         Enter your preferred flight class:\n";
        cout<<"                                                                                         1.Business Class\n                                                                                         2.Economic Class\n";
		cout<<"                                                                                         Choose your option : ";cin>>f_classi;
        	if(f_classi==1)
        	{
		      strcpy(fl_classi,"Business Class");
		      agebuscati();
		    }
			else if(f_classi==2)
			{
		      strcpy(fl_classi,"Economic Class");
		      agecategoryi();
	        }
			else
			{
				cout<<"ERROR!!!"<<endl;
				return flight_classi();//function call
			}
	} 
	int agebuscati()// function for age category and price for business class
    {
    	cout<<"\n                                                                                         Passenger Age Category:\n";
        cout<<"                                                                                         1.Infant(1-2)\n                                                                                         2.Children(3-12)\n                                                                                         3.Adult(>12)";
        cout<<"\n                                                                                         Select your Category : ";cin>>cati;
        if(cati==1)
        {
		    strcpy(age_cati,"INFANT");
		    if((srci==1 && desti==3) || (srci==3 && desti==1))//condition
          {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.7000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8000\n";
            cout << "                                                                                         3.Emirates\t\tRs.8500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;
        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.7500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Emirates\t\tRs.6500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.5500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.7500\n";
            cout << "                                                                                         3.Emirates\t\tRs.6500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2)  )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5500\n";
            cout << "                                                                                         3.Emirates\t\tRs.6500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.6500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4500\n";
            cout << "                                                                                         3.Emirates\t\tRs.5000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2))//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.5000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.5500\n";
            cout << "                                                                                         3.Emirates\t\tRs.4500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
	  }
			else if(cati==2)
			{
		strcpy(age_cati,"Children");
		if((srci==1 && desti==3) || (srci==3 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.8000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Emirates\t\tRs.8500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.10000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.10500\n";
            cout << "                                                                                         3.Emirates\t\tRs.11000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.10000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.11500\n";
            cout << "                                                                                         3.Emirates\t\tRs.10500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.10000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.11000\n";
            cout << "                                                                                         3.Emirates\t\tRs.10500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.10000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.10500\n";
            cout << "                                                                                         3.Emirates\t\tRs.11000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2) )//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.10000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.10500\n";
            cout << "                                                                                         3.Emirates\t\tRs.11500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
	}
		    else if(cati=3)
		    {
		    strcpy(age_cati,"Adult");
		if((srci==1 && desti==3) || (srci==3 && desti==1))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.20000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.20500\n";
            cout << "                                                                                         3.Emirates\t\tRs.21500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.23000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.22500\n";
            cout << "                                                                                         3.Emirates\t\tRs.26500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.25000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.24500\n";
            cout << "                                                                                         3.Emirates\t\tRs.21500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.27800\n";
            cout << "                                                                                         2.INDIGO\t\tRs.25500\n";
            cout << "                                                                                         3.Emirates\t\tRs.24500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.27000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.28500\n";
            cout << "                                                                                         3.Emirates\t\tRs.29500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2) )//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Business and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.24000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.24500\n";
            cout << "                                                                                         3.Emirates\t\tRs.25500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
    }
			else
			{
				cout<<"                                                                                         ERROR!!!"<<endl;
				return agebuscati();//function call
			}
}
int agecategoryi()// function for age category and price for business class
    {
    	cout<<"\n                                                                                         Passenger Age Category:\n";
        cout<<"                                                                                         1.Infant(1-2)\n                                                                                         2.Children(3-12)\n                                                                                         3.Adult(>12)\n";
        cout<<"                                                                                         Select your Category\n";
        cin>>cati;
        	if(cati==1)
        	{
		strcpy(age_cati,"INFANT");
		if((srci==1 && desti==3) || (srci==3 && desti==1))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.3000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4000\n";
            cout << "                                                                                         3.Emirates\t\tRs.3500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.3500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4500\n";
            cout << "                                                                                         3.Emirates\t\tRs.2500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.2500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4500\n";
            cout << "                                                                                         3.Emirates\t\tRs.2500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2)  )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.3000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4000\n";
            cout << "                                                                                         3.Emirates\t\tRs.3500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.3500\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4000\n";
            cout << "                                                                                         3.Emirates\t\tRs.5500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2))//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Infant:\n"<<endl;
            cout << "                                                                                         Airline:\t\tInfant\n";
            cout << "                                                                                         1.Vistara\t\tRs.3000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.4000\n";
            cout << "                                                                                         3.Emirates\t\tRs.3500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
	}
			else if(cati==2)
			{
		strcpy(age_cati,"Children");
		if((srci==1 && desti==3) || (srci==3 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.6000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.6500\n";
            cout << "                                                                                         3.Emirates\t\tRs.7500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.9000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.9500\n";
            cout << "                                                                                         3.Emirates\t\tRs.10000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.8000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Emirates\t\tRs.9500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.7000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.7000\n";
            cout << "                                                                                         3.Emirates\t\tRs.6500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.9000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.9500\n";
            cout << "                                                                                         3.Emirates\t\tRs.9000\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2) )//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Children:\n"<<endl;
            cout << "                                                                                         Airline:\t\tChildren\n";
            cout << "                                                                                         1.Vistara\t\tRs.8000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.8500\n";
            cout << "                                                                                         3.Emirates\t\tRs.9500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
	}
		    else if(cati=3)
		    {
		    strcpy(age_cati,"Adult");
		if((srci==1 && desti==3) || (srci==3 && desti==1))//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.12000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.13500\n";
            cout << "                                                                                         3.Emirates\t\tRs.12500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==4) || (srci==4 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.12000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.13500\n";
            cout << "                                                                                         3.Emirates\t\tRs.12500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==1 && desti==5) || (srci==5 && desti==1) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.15000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.16500\n";
            cout << "                                                                                         3.Emirates\t\tRs.17500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==3) || (srci==3 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.18800\n";
            cout << "                                                                                         2.INDIGO\t\tRs.15500\n";
            cout << "                                                                                         3.Emirates\t\tRs.16500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==4) || (srci==4 && desti==2) )//condition
        {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.17000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.18500\n";
            cout << "                                                                                         3.Emirates\t\tRs.19500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
        else if((srci==2 && desti==5) || (srci==5 && desti==2) )//condition
         {
         	cout<<"\n                                                                                       $$$  FLIGHT PRICE  $$$      "<<endl;
        	cout<<"                                                                                         Your selected class is Economic and selected Age Category is Adult:\n"<<endl;
            cout << "                                                                                         Airline:\t\tAdult:\n";
            cout << "                                                                                         1.Vistara\t\tRs.14000\n";
            cout << "                                                                                         2.INDIGO\t\tRs.14500\n";
            cout << "                                                                                         3.Emirates\t\tRs.15500\n";
            cout<<"\n                                                                                         Your Money will be deducted according to your selected Airline!!!\n"<<endl;

        }
    }
			else
			{
				cout<<"                                                                                         ERROR!!!"<<endl;
				return agecategoryi();
			}
		}	
    int select_flighti()//function declaration and definition for selecting flight
    {
    	cout<<"                                                                                         Select your airline from below options:\n                                                                                         1.Vistara \t 2.Indigo \t 3.Emirates\n"<<endl;
        cout << "\n                                                                                         Enter your choice : ";cin >> choicei;
        switch(choicei)
        {
        case 1:
            cout << "\n                                                                                         Flight selected:" <<endl;
            cout << "                                                                                         Vistara" << endl;
            strcpy(f_i,"Vistara ");//copy to string
            cout << "                                                                                         Departure Time: 10:00 AM" << endl;
            strcpy(tojdi,"10:00 AM");
            cout << "                                                                                         Arrival Time: 14:05 PM" << endl;//copy to string
            strcpy(tojai,"14:05 PM");//copy to string
            break;
        case 2://condition
               cout << "\n                                                                                         Flight selected:" << endl;
               cout << "                                                                                         INDIGO" << endl;
               strcpy(f_i,"INDIGO  ");//copy to string
               cout << "                                                                                         Departure Time: 14:00 PM" << endl;
               strcpy(tojdi,"14:00 PM");
               cout << "                                                                                         Arrival Time: 18:05 PM" << endl;
                strcpy(tojai,"18:05 PM");//copy to string
                break;
        case 3:
            cout << "\n                                                                                         Flight selected:" << endl;
            cout << "                                                                                         Emirates" << endl;
            strcpy(f_i,"Emirates");//copy to string
            cout << "                                                                                         Departure Time: 18:00 PM" << endl;
            strcpy(tojdi,"18:00 PM");
            cout << "                                                                                         Arrival  Time: 22:05 PM" << endl;
            strcpy(tojai,"22:05 PM");//copy to string
            break;
        default:
            cout << "                                                                                         Wrong input entered" << endl;
            return select_flighti();
        }
    }
};
class passenger: public d_booking,public i_booking//class passenger publicly inherited from class d_booking and i_booking
{
protected:
    char f_name[20],l_name[20],email[50],meal[50],gen[50];
    int age,gender,n,D,M,Y;
    char c_no[100];
public:
    void p_detail(int x)
    {   if(x==1)
        { dj_detail();
          flight_class();
          select_flight();
        }
          else
          {  ij_detail();
             flight_classi();
             select_flighti();
          }
        cout<<"\n\n                                                                                         Enter passenger details";
        cout << "\n                                                                                         First Name :"; cin >> f_name;
        cout << "                                                                                         Last Name :"; cin >> l_name;
    }
     int gender_detail()//to check gender input as valid
     {
        cout << "\n                                                                                         Gender:\n";
		cout<<"                                                                                         1.Male\n";
		cout<<"                                                                                         2.Female\n";
		cout<<"                                                                                         3.Others\n";
        cout<<"                                                                                         Choose your option : ";cin >> gender;
        if(gender==1)
		strcpy(gen,"MALE");
			else if(gender==2)
		strcpy(gen,"FEMALE");
		    else if(gender=3)
		    strcpy(gen,"OTHERS");
			else
			{
				cout<<"                                                                                         ERROR!!!"<<endl;
				return gender_detail();
			}
     }
       void  more_details()//to take more details of the passenger
       {int v,o;
       cout << "                                                                                         Date of Birth (DD/MM/YYYY) :\n";
       cout << "                                                                                         Day [DD] : "; cin >> D;
	   if(D>31)
	   {
	   	cout<<"                                                                                         INNALID INPUT!! PLEASE TRY AGAIN \n";
	   	return more_details();
	   }
	   cout<< "\n                                                                                         Month [MM] : "; cin>> M;
	   if(M<0 || M>12)
	   {
	   	 cout<<"\n                                                                                         INVALID INPUT\n"<<"                                                                                         Months can only be in range of (1-12)\n";
	   	 return more_details();
	   }
	   if(M==2 && D>29)
	   {
	   	cout<<"\n                                                                                         INVALID INPUT \n";
	   	return more_details();
	   }
	   if(M == 4 && D>30)
	   {
	   	cout<<"\n                                                                                         INVALID INPUT \n";
	   	return more_details();
	   }
	   if(M == 6 && D>30)
	   {
	   	cout<<"\n                                                                                         INVALID INPUT \n";
	   	return more_details();
	   }
	   if(M == 9&& D>30)
	   {
	   	cout<<"\n                                                                                         INVALID INPUT \n";
	   	return more_details();
	   }
	   if(M == 11 && D>30)
	   {
	   	cout<<"\n                                                                                         INVALID INPUT \n";
	   	return more_details();
	   }
	   cout<< "\n                                                                                         Year [YYYY] : ";cin>> Y;
	   if(Y<1900 || Y>2021)
	   {
	   	cout<<"\n                                                                                         INVALID DATE OF BIRTH !! \n";
	   	return more_details();
	   }
       cout << "\n                                                                                         Age : "; cin >> age;
        cout << "                                                                                         Email Id : ";cin >> email;
        cout << "                                                                                         Contact no.(10 digits) : ";cin >> c_no;
        cout << "                                                                                         Meal type : \n" ;
       {
		   	cout<<"                                                                                         1.Vegetarian\n                                                                                         2.Non-Vegetarian\n                                                                                         3.No Meal\n";
            cout<<"                                                                                         Choose your option : ";cin >> n;
			if(n==1)
		strcpy(meal,"Vegetarian");
			else if(n==2)
		strcpy(meal,"Non Vegetarian");
		    else if(n=3)
		    strcpy(meal,"NO Meal");
			else
			{
				cout<<"ERROR!!!"<<endl;
			}
		}
        cout << "\n                                                                                         Details Entered :\n";
        cout << "                                                                                         Name : " << f_name << " " << l_name << endl;
        cout << "                                                                                         Gender : " << gen << endl;     
        cout<<"                                                                                         Date of Birth(DD/MM/YYYY) : "<< D <<"/"<<M<<"/"<<Y<< endl;
        cout << "                                                                                         Age : " << age << endl;
        cout << "                                                                                         Email id : " << email << endl;
        cout << "                                                                                         Contact No. : " << c_no << endl;
        cout << "                                                                                         Meal Type : " << meal << endl;
    }
     int getpnr()//function to get pnr for domestic booking
        {
            return pnr;
        }

     int getpnri()//function to get pnr for international booking
     {
         return pnri;
     }

     void disp()//function to display details for domestic booking
     {
     	 cout<<"\n\n                                                                                         Your Ticket is Booked :)  ";
     	 cout<<"\n                                                                                         Ticket Details ";                  
         cout<<"\n                                                                                         PNR             : " <<"AIR135" << pnr;
         cout<<"\n                                                                                         Flight          :" << f_d;                 
         cout<<"\n                                                                                         Name            :" << f_name <<" " << l_name;
         cout<<"\n                                                                                         Date of Journey :" << dd<<"/"<<mm<<"/"<<yy;
         cout<<"\n                                                                                         Departure Time  : "<<todh ;
         cout<<"\n                                                                                         Arrival Time    :" << toja;
         cout<<"\n                                                                                                  HAPPY JOURNEY!!";
         cout<<"\n                                                                                         Thanks for visiting us!!\n                                                                                         Have a nice day!";
         Sleep(1000);
	 }
     
      void dispi()//function to display details for international booking
     {
     	 cout<<"\n\n                                                                                         Your Ticket is Booked :)  ";
     	 cout<<"\n                                                                                         Ticket Details ";                  
         cout<<"\n                                                                                         PNR             : " <<"AIR135" << pnri;
         cout<<"\n                                                                                         Flight          :" << f_i;                 
         cout<<"\n                                                                                         Name            :" << f_name <<" " << l_name;
         cout<<"\n                                                                                         Date of Journey :" << ddi<<"/"<<mmi<<"/"<<yyi;
         cout<<"\n                                                                                         Departure Time  :" << tojdi;
         cout<<"\n                                                                                         Arrival Time    :" << tojai;
         cout<<"\n                                                                                                  HAPPY JOURNEY!!";
         cout<<"\n                                                                                         Thanks for visiting us!!\n                                                                                         Have a nice day!";
         Sleep(1000);
	 }

};

class seats:public d_booking 
{
	protected:
		 int bus,eco,k ;
      int NoOfSeats;
	public:
	int seat_co()
		{
			bus_eco:
				if(bus>=0&&eco>=0)
				{
					cout<<"\n                                                                                         Do you really want to book your seats  ?? "<<endl;
					cout<<"                                                                                         If yes then Press 1 for BUSINESS CLASS and Press 2 for ECONOMIC CLASS    "  ;k = getch();
					switch(k)
					{
						case 49:
						{
							cout<<endl<<"                                                                                         Business Class";
							cout<<endl<<"                                                                                         Press 1 To Allow For Booking : "; cin>>NoOfSeats;
							if(NoOfSeats!=1)
							{
								cout<<"                                                                                         INVALID INPUT!!!";
								return flight_class();
							}
							 if(NoOfSeats<=bus)
							{
								cout<<endl<<"                                                                                         Seat is Booked.\n\n";
								bus=bus-NoOfSeats;
							}
							else
							{
								cout<<"                                                                                         Do you wish to book the seat\n";
								cout<<"                                                                                         Press 1 for YES\n";
								cout<<"                                                                                         Press 2 for NO   "; k = getch();
								if(k==49)
								{
									NoOfSeats = bus;
								 	cout<<"                                                                                         Seat is booked\n\n";
								 	bus=0;
								}
								else
								{
									cout<<endl<<"                                                                                         See you again.\n";
									exit(0);
								}
							}
							break;
						}
						
					case 50:
						{
							cout<<endl<<"                                                                                         Economic Class";
							cout<<endl<<"                                                                                         Press 1 To Allow For Booking : "; cin>>NoOfSeats;
							if(NoOfSeats!=1)
							{
								cout<<"                                                                                         INVALID INPUT!!!";
								return flight_class();
							}
							if(NoOfSeats<=eco)
							{
								cout<<endl<<"                                                                                         Seat is Booked.\n\n";
								eco=eco-NoOfSeats;
							}
							else
							{
								cout<<"                                                                                         Do you wish to book the seat\n";
								cout<<"                                                                                         Press 1 for YES\n";
								cout<<"                                                                                         Press 2 for NO   "; k = getch();
								if(k==49)
								{
									NoOfSeats = eco;
									cout<<endl<<"                                                                                         Seat is Booked\n\n";
									eco=0;
								}
								else
								{
									cout<<endl<<"                                                                                         See you again.\n";
									exit(0);
								}
							}
							break;
						}
					
					default:
						{
							cout<<"                                                                                         Error!\n";
							goto bus_eco;
						}
				}
			}
			else
			{
				cout<<endl<<"                                                                                         Sorry no seats available\n";
				cout<<"                                                                                         Have a nice day!";
				exit(0);
			}
		}
};
class seatsi:public i_booking
{
	protected:
    int busi,ecoi,h;
    int NoOfSeatsi;
    public:
	int seatsi_co()
		{
			busi_ecoi:
				if(busi>=0 && ecoi>=0)
				{
					cout<<endl<<"                                                                                         Do you really want to book your seats"<<endl<<"                                                                                         If yes then Press 1 for BUSINESSS CLASS and Press 2 for ECONOMIC CLASS   ";h= getch();
					switch(h)
					{
						case 49:
						{
							cout<<endl<<"                                                                                         Business Class";
							cout<<endl<<"                                                                                         Press 1 To Allow For Booking : "; cin>>NoOfSeatsi;
							if(NoOfSeatsi!=1)
							{
								cout<<"                                                                                         INVALID INPUT!!!";
								return flight_classi();
							}
							if(NoOfSeatsi<=busi)
							{
								cout<<endl<<"                                                                                         Seats is Booked.\n\n";
								busi=busi-NoOfSeatsi;
							}
							else
							{
									cout<<"                                                                                         Do you wish to book the seat\n";
								cout<<"                                                                                         Press 1 for YES\n";
								cout<<"                                                                                         Press 2 for NO   "; h = getch();
								if(h==49)
								{
									NoOfSeatsi = busi;
								 	cout<<"                                                                                         Seat is booked\n\n";
								 	busi=0;
								}
								else
								{
									cout<<endl<<"                                                                                         See you again.\n";
									exit(0);
								}
							}
							break;
						}
						
					case 50:
						{
							cout<<endl<<"                                                                                         Economic Class";
							cout<<endl<<"                                                                                         Press 1 To Allow For Booking : ";cin>>NoOfSeatsi;
							if(NoOfSeatsi!=1)
							{
								cout<<"                                                                                         INVALID INPUT!!!";
								return flight_classi();
							}
							if(NoOfSeatsi<=ecoi)
							{
								cout<<endl<<"                                                                                         Seat is Booked.\n\n";
								ecoi=ecoi-NoOfSeatsi;
							}
							else
							{
								cout<<"                                                                                         Do you wish to book the seat\n";
								cout<<"                                                                                         Press 1 for YES\n";
								cout<<"                                                                                         Press 2 for NO   "; h = getch();
								if(h==49)
								{
									NoOfSeatsi = ecoi;
									cout<<endl<<"                                                                                         Seat is Booked\n\n";
									ecoi=0;
								}
								else
								{
									cout<<endl<<"                                                                                         See you again.\n";
									exit(0);
								}
							}
							break;
						}
					
					default:
						{
							cout<<"                                                                                         Error!\n";
							goto busi_ecoi;
						}
				}
			}
			else
			{
				cout<<endl<<"                                                                                         Sorry no seats available\nHave a nice day!";
				exit(0);
			}
		}
};
class payment//class for payment
{
protected:
    long int choice1,bank,date,cvv,user_id;
    char card[100];
    char name[100];
    char password[100];
public:
    void pay_detail()
    {     cout << "\n\n                                                                                         How would you like to pay ?";
        cout << "\n                                                                                         1.Debit Card ";
		cout<<"\n                                                                                         2.Credit Card ";
		cout<<"\n                                                                                         3.Net Banking";
        cout << "\n\n                                                                                         Enter your choice : ";cin >> choice1;
        switch(choice1)
        {
        case 1:
            cout << "\n                                                                                         Enter card no.(16 Digits) : ";cin >> card;
            cout<<"\n                                                                                         Enter Card Holder Name : ";cin>>name;
            cout << "\n                                                                                         Enter expiry date : ";cin >> date;
            cout << "\n                                                                                         Enter CVV no. : ";cin >> cvv;
            cout << "\n                                                                                         Transaction Successful    \n";
            break;
        case 2:
            cout << "\n                                                                                         Enter card no.(16 Digits) : ";cin >> card;
            cout<<"\n                                                                                         Enter Card Holder Name : ";cin>>name;
            cout << "\n                                                                                         Enter expiry date : "; cin >> date;
            cout << "\n                                                                                         Enter password : ";cin>>password;
            cout << "\n                                                                                         Transaction Successful  \n";
            break;
        case 3:
            cout << "\n                                                                                         Banks Available : ";
			cout<<"\n                                                                                         1.State Bank of India\t 2.HDFC Bank\t 3. Bank of America\t 4.DBS Bank\t 5.ICICI Bank\n;";
            cout << "\n                                                                                         Select your bank : ";cin >> bank;
            cout << "\n                                                                                         You have selected : " << bank;
            cout << "\n                                                                                         Enter user id : ";cin >> user_id;
            cout << "\n                                                                                         Enter password : ";cin >> password;
            cout << "\n                                                                                         Transaction Successful   \n";
            break;
        default:
            cout << "\n                                                                                         Wrong input entered!!  \n                                                                                         Try again!!\n\n";
            return pay_detail();
        }
    }

};

void createfile(passenger p)//file creation for domestic booking
{  ofstream fin("domestic.txt",ios::app);
   fin.write((char*)&p,sizeof(p));//writing to file
   fin.close();//closing file
}

void createfilei(passenger p)//opening a file for international booking
{  ofstream fin("international.txt",ios::app);
   fin.write((char*)&p,sizeof(p));//writing to file
   fin.close();//closing file
}
main()
{ 
        system("color E0");
        int opt;
        cout<<"\n\n\n\n                                           ============================================================================================================================"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 *******************************************************************************************              |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                            WELCOME TO AIRLINE MANAGEMENT SYSTEM                                          |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                          HELLO!!!                                                        |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 **************************************** Are U A ? ****************************************              | \n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                        1.USER                                                            |\n";
        cout<<"                                           |                                                        3.EXIT                                                            |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl; 
	    cout<<"                                           ============================================================================================================================"<<endl;
	    cout<<"                                                                                                 Enter your choice : ";  cin>>opt;     
        Sleep(700);
        system("cls");
    if(opt==1)
       {  login_page();
       }
else if(opt=3)
  {
  	exit(1);
  }	  

    class d_booking d1;//object for class d_booking
    class i_booking i1;//object for class i_booking
    class passenger p1;//object for class passenger
    class seats s1;
    class seatsi s2;
    class payment p2;//object for class payment
    int ch,ch1,n;
    char input;

    do
    {
    	system("CLS");
    cout<<"\n\n\n\n                                           ============================================================================================================================"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 *******************************************************************************************              |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                              WELCOME TO AIRLINE MANAGEMENT SYSTEM                                        |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                         BOOK YOUR FLIGHTS TICKETS AT AFFORDABLE PRICES!                                  |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ****************************************    MENU   ****************************************              | \n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                        1.BOOK TICKET                                                     |"<<endl;                                                                                
        cout<<"                                           |                                                        4.FILE A COMPLAINT                                                |"<<endl;
        cout<<"                                           |                                                        5.ABOUT US                                                        |"<<endl;
        cout<<"                                           |                                                        6.EXIT                                                            |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl; 
	    cout<<"                                           ============================================================================================================================"<<endl;
	    cout<<"                                                                                                 Enter your choice : ";  cin>>ch;   
    
	  switch(ch)
      {
          case 1:
          system("CLS");
          cout<<"\n\n\n\n                                           ============================================================================================================================"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 *******************************************************************************************              |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                              WELCOME TO AIRLINE MANAGEMENT SYSTEM                                        |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                         BOOK YOUR FLIGHTS TICKETS AT AFFORDABLE PRICES!                                  |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ****************************************    BOOKING   ****************************************           | \n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                        1.DOMESTIC FLIGHTS                                                |\n";
        cout<<"                                           |                                                        2.INTERNATIONAL FLIGHTS                                           |\n";
        cout<<"                                           |                                                                                                                          |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;                                                                                                                   
	    cout<<"                                           ============================================================================================================================"<<endl;
        cout << "\n                                                                                         Please enter your option : "; cin >> ch1;
        switch(ch1)
              {
                   case 1://for booking domestic ticket
                        system("CLS");
                        cout<<"\n                               ****************************************************************************************************************************************************                   ";
                        cout<<"\n\n                                                                                                      DOMESTIC BOOKING                                                ";   						cout<<"\n\n\n\n\n";
						p1.d_pnr();
						p1.p_detail(1);
                        p1.gender_detail();
                        p1.more_details();
                        s1.seat_co();
                        p2.pay_detail();
                        p1.disp();
                        createfile(p1);//call to create file
                        cout<<"\n                               ****************************************************************************************************************************************************                   ";
                        break;
                   case 2: //for booking international ticket
                           system("CLS");
                           cout<<"\n                               ****************************************************************************************************************************************************                   ";
						   p1.i_pnr();
						   p1.p_detail(2);
                           p1.gender_detail();
                           p1.more_details();
                           s2.seatsi_co();
                           p2.pay_detail();
                           p1.dispi();
                           createfilei(p1);//call to create file
                           cout<<"\n                               ****************************************************************************************************************************************************                   ";
						   break;
                   default://wrong input
                    cout << "                                                                                                 Wrong input entered!! \n                                                                                                 Try again\n\n\n" << endl;
                    return main();
              }
          break;
                   case 4:
			system("CLS");
			char wr[2000];
			cout<<"\n\n\n\n                                           ============================================================================================================================"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 *******************************************************************************************              |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                              WELCOME TO AIRLINE MANAGEMENT SYSTEM                                        |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                         BOOK YOUR FLIGHTS TICKETS AT AFFORDABLE PRICES!                                  |"<<endl;
        cout<<"                                           |                 ><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>              |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                 ****************************************     COMPLAINT   ****************************************              | \n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |\n";
        cout<<"                                           |                                                                                                                          |"<<endl;
        cout<<"                                           |                                                                                                                          |"<<endl;                                                                                                                   
	    cout<<"                                           ============================================================================================================================"<<endl;
		cout<<"                                                                                           WRITE YOUR COMPLAINT : "; cin>>wr;
		break;
		case 5:
		 system("cls");
        cout<<"\n\n\n\n\n\n\n\n\n\n\n                                                            ****************************************     ABOUT US   ****************************************               \n";
		cout<<"\n\n\n                                                                                                 WE WILL RIDE,";
		cout<<"\n                                                                                                 WE WILL FLY";
		cout<<"\n                                                                                                 CHASE THE WIND";
		cout<<"\n                                                                                                 AND TOUCH THE SKY \n\n\n\n"<<endl;
		break;
		case 6:
			system("cls");
			cout<<"\n\n\n\n\n\n\n\n\n\n\n                                                                                                 Thanks for Visiting !!";
			exit(0);
        default://for wrong input
           
           cout << "\n\n\\n                                                                                                 Wrong input entered!! \n                                                                                                 Try again.\n\n\n\n" << endl;
           exit(0);
      }
      
    cout<<"\n\n\n                                                                                                 Do you wish to continue : (y/n)" << endl;
    cin >> input;
    
  }while(input=='n' || input=='y'|| input=='Y'|| input=='N');//condition for do while loop
  return main();
  
}


